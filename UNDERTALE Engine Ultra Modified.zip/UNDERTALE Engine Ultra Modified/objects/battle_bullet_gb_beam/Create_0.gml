_type=0;
image_index=1;
image_xscale=0;
image_yscale=0;
dmg = 1
