intensity = 1;
